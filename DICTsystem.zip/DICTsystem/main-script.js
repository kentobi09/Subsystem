//Apply the colors in respective status

document.addEventListener("DOMContentLoaded", function () {
  const statusCells = document.querySelectorAll(
    ".table.table-hover tbody tr td:nth-last-of-type(4)"
  );

  statusCells.forEach((statusCell) => {
    const status = statusCell.textContent.trim();

    if (status === "Passed") {
      statusCell.classList.add("table-success");
    } else if (status === "Failed") {
      statusCell.classList.add("table-danger");
    } else if (status === "Pending") {
      statusCell.classList.add("table-info");
    }
  });
});

//Listen to the toggle of name filter
document.addEventListener("DOMContentLoaded", function () {
  const descCheckbox = document.getElementById("flexSwitchCheckDesc");
  const ascCheckbox = document.getElementById("flexSwitchCheckAsc");

  descCheckbox.addEventListener("change", function (event) {
    event.preventDefault();
    if (this.checked) {
      ascCheckbox.checked = false;
      document.getElementById("nameFilterForm").sortName.value = "desc";
      document.getElementById("nameFilterForm").submit();
    } else {
      document.getElementById("nameFilterForm").submit();
    }
  });

  ascCheckbox.addEventListener("change", function (event) {
    event.preventDefault();
    if (this.checked) {
      descCheckbox.checked = false;
      document.getElementById("nameFilterForm").sortName.value = "asc";
      document.getElementById("nameFilterForm").submit();
    } else {
      document.getElementById("nameFilterForm").submit();
    }
  });
});

//Listen to the toggle of ID filter
document.addEventListener("DOMContentLoaded", function () {
  const oldestCheckbox = document.getElementById("flexSwitchCheckOldest");

  oldestCheckbox.addEventListener("change", function () {
    const form = document.getElementById("idFilterForm");
    const url = new URL(window.location.href);
    if (this.checked) {
      url.searchParams.set("sortID", "oldest");
    } else {
      url.searchParams.delete("sortID");
    }
    form.action = url.toString();
    form.submit();
  });
});

//Listen to the date filter exam inputs
$(function () {
  $('input[name="datefilter_examination"]').daterangepicker({
    autoUpdateInput: false,
    locale: {
      cancelLabel: "Clear",
    },
    ranges: {
      Today: [moment(), moment()],
      "Last 7 Days": [moment().subtract(6, "days"), moment()],
      "Last 30 Days": [moment().subtract(29, "days"), moment()],
      "Last Month": [
        moment().subtract(1, "month").startOf("month"),
        moment().subtract(1, "month").endOf("month"),
      ],
    },
  });

  $('input[name="datefilter_examination"]').on(
    "apply.daterangepicker",
    function (ev, picker) {
      $(this).val(
        picker.startDate.format("MM/DD/YYYY") +
          " - " +
          picker.endDate.format("MM/DD/YYYY")
      );
      var params = new URLSearchParams(window.location.search);
      params.set(
        "start_date_examination",
        picker.startDate.format("YYYY-MM-DD")
      );
      params.set("end_date_examination", picker.endDate.format("YYYY-MM-DD"));

      params.delete("date_preset_notification");
      params.delete("start_date_notification");
      params.delete("end_date_notification");

      window.location.search = params.toString();
    }
  );

  $('input[name="datefilter_examination"]').on(
    "cancel.daterangepicker",
    function (ev, picker) {
      $(this).val("");
      var params = new URLSearchParams(window.location.search);
      params.delete("start_date_examination");
      params.delete("end_date_examination");
      window.location.search = params.toString();
    }
  );

  var params = new URLSearchParams(window.location.search);
  if (
    params.has("start_date_examination") &&
    params.has("end_date_examination")
  ) {
    var start = moment(params.get("start_date_examination"));
    var end = moment(params.get("end_date_examination"));
    $('input[name="datefilter_examination"]').val(
      start.format("MM/DD/YYYY") + " - " + end.format("MM/DD/YYYY")
    );
  }
  //Listen to the date filter notification inputs
  $('input[name="datefilter_notification"]').daterangepicker({
    autoUpdateInput: false,
    locale: {
      cancelLabel: "Clear",
    },
    ranges: {
      Today: [moment(), moment()],
      "Last 7 Days": [moment().subtract(6, "days"), moment()],
      "Last 30 Days": [moment().subtract(29, "days"), moment()],
      "Last Month": [
        moment().subtract(1, "month").startOf("month"),
        moment().subtract(1, "month").endOf("month"),
      ],
    },
  });

  $('input[name="datefilter_notification"]').on(
    "apply.daterangepicker",
    function (ev, picker) {
      $(this).val(
        picker.startDate.format("MM/DD/YYYY") +
          " - " +
          picker.endDate.format("MM/DD/YYYY")
      );
      var params = new URLSearchParams(window.location.search);
      params.set(
        "start_date_notification",
        picker.startDate.format("YYYY-MM-DD")
      );
      params.set("end_date_notification", picker.endDate.format("YYYY-MM-DD"));

      params.delete("start_date_examination");
      params.delete("end_date_examination");

      window.location.search = params.toString();
    }
  );

  $('input[name="datefilter_notification"]').on(
    "cancel.daterangepicker",
    function (ev, picker) {
      $(this).val("");
      var params = new URLSearchParams(window.location.search);
      params.delete("start_date_notification");
      params.delete("end_date_notification");
      window.location.search = params.toString();
    }
  );

  if (
    params.has("start_date_notification") &&
    params.has("end_date_notification")
  ) {
    var startNotification = moment(params.get("start_date_notification"));
    var endNotification = moment(params.get("end_date_notification"));
    $('input[name="datefilter_notification"]').val(
      startNotification.format("MM/DD/YYYY") +
        " - " +
        endNotification.format("MM/DD/YYYY")
    );
  }

  $('input[name="datefilter_examination"]').on("keypress", function (e) {
    if (e.which === 13) {
      if ($(this).val().trim() === "") {
        $(this).trigger("cancel.daterangepicker");
      } else {
        $(this).trigger("apply.daterangepicker");
      }
    }
  });

  $('input[name="datefilter_notification"]').on("keypress", function (e) {
    if (e.which === 13) {
      if ($(this).val().trim() === "") {
        $(this).trigger("cancel.daterangepicker");
      } else {
        $(this).trigger("apply.daterangepicker");
      }
    }
  });
});

//Listen to the submit of date filters
document.addEventListener("DOMContentLoaded", function () {
  let formChanged = false;
  const statusForm = document.getElementById("statusForm");
  const nameFilterForm = document.getElementById("nameFilterForm");
  const idFilterForm = document.getElementById("idFilterForm");
  const offcanvas = document.getElementById("offcanvasNavbar");

  function handleFormChange() {
    formChanged = true;
  }

  function submitForms() {
    const dateExamination = document.querySelector(
      'input[name="datefilter_examination"]'
    ).value;
    const dateNotification = document.querySelector(
      'input[name="datefilter_notification"]'
    ).value;
    const statusChecked =
      Array.from(document.querySelectorAll('input[name="status[]"]:checked'))
        .length > 0;

    if (formChanged) {
      const formData = new FormData();

      [statusForm, nameFilterForm, idFilterForm].forEach((form) => {
        for (let pair of new FormData(form).entries()) {
          if (pair[1] !== "") {
            formData.append(pair[0], pair[1]);
          }
        }
      });

      if (dateExamination)
        formData.append(
          "start_date_examination",
          moment(dateExamination.split(" - ")[0], "MM/DD/YYYY").format(
            "YYYY-MM-DD"
          )
        );
      formData.append(
        "end_date_examination",
        moment(dateExamination.split(" - ")[1], "MM/DD/YYYY").format(
          "YYYY-MM-DD"
        )
      );
      if (dateNotification)
        formData.append(
          "start_date_notification",
          moment(dateNotification.split(" - ")[0], "MM/DD/YYYY").format(
            "YYYY-MM-DD"
          )
        );
      formData.append(
        "end_date_notification",
        moment(dateNotification.split(" - ")[1], "MM/DD/YYYY").format(
          "YYYY-MM-DD"
        )
      );

      const searchParams = new URLSearchParams(formData);
      const newUrl = searchParams.toString()
        ? window.location.pathname + "?" + searchParams.toString()
        : window.location.pathname;

      if (window.location.href !== newUrl) {
        window.location.href = newUrl;
      }

      formChanged = false;
    }
  }

  [statusForm, nameFilterForm, idFilterForm].forEach((form) => {
    form.addEventListener("change", handleFormChange);
  });

  document
    .querySelector('input[name="datefilter_examination"]')
    .addEventListener("change", handleFormChange);
  document
    .querySelector('input[name="datefilter_notification"]')
    .addEventListener("change", handleFormChange);

  offcanvas.addEventListener("hidden.bs.offcanvas", submitForms);
  window.addEventListener("beforeunload", submitForms);

  const urlParams = new URLSearchParams(window.location.search);
  const statusValues = urlParams.getAll("status[]");
  statusValues.forEach((value) => {
    const checkbox = document.querySelector(
      `input[name="status[]"][value="${value}"]`
    );
    if (checkbox) checkbox.checked = true;
  });
});

// //Code to display the modal
// document.addEventListener("DOMContentLoaded", function () {
//   const tableBody = document.getElementById("applicant-table-body");
//   const applicantModal = new bootstrap.Modal(
//     document.getElementById("applicantModal")
//   );

//   tableBody.addEventListener("click", function (event) {
//     const row = event.target.closest(".applicant-row");
//     if (row) {
//       const applicantID = row.querySelector(".applicant-id").textContent.trim();
//       const name = row.querySelector(".applicant-name").textContent.trim();
//       const sex = row.querySelector(".applicant-sex").textContent.trim();
//       const province = row
//         .querySelector(".applicant-province")
//         .textContent.trim();
//       const contactNumber = row
//         .querySelector(".contact-number")
//         .textContent.trim();
//       const emailAddress = row
//         .querySelector(".email-address a")
//         .textContent.trim();
//       const notificationDate = row
//         .querySelector(".applicant-notification-date")
//         .textContent.trim();
//       const examDate = row
//         .querySelector(".applicant-exam-date")
//         .textContent.trim();
//       const examVenue = row
//         .querySelector(".applicant-exam-venue")
//         .textContent.trim();
//       const proctor = row.querySelector(".proctor").textContent.trim();
//       const status = row.querySelector(".status").textContent.trim();
//       const score1 = row.querySelector(".applicant-score1")
//         ? row.querySelector(".applicant-score1").textContent.trim()
//         : "N/A";
//       const score2 = row.querySelector(".applicant-score2")
//         ? row.querySelector(".applicant-score2").textContent.trim()
//         : "N/A";
//       const score3 = row.querySelector(".applicant-score3")
//         ? row.querySelector(".applicant-score3").textContent.trim()
//         : "N/A";
//       const totalScore = row.querySelector(".total-score")
//         ? row.querySelector(".total-score").textContent.trim()
//         : "N/A";
//       const applicationForm = row.querySelector(".attachment a").href;

//       populateModal({
//         applicantID,
//         name,
//         sex,
//         province,
//         contactNumber,
//         emailAddress,
//         notificationDate,
//         examDate,
//         examVenue,
//         proctor,
//         status,
//         score1,
//         score2,
//         score3,
//         totalScore,
//         applicationForm,
//       });

//       applicantModal.show();
//     }
//   });
// });

// function populateModal(data) {
//   document.getElementById("modal-applicantID").textContent = data.applicantID;
//   document.getElementById("modal-name").textContent = data.name;
//   document.getElementById("modal-sex").textContent = data.sex;
//   document.getElementById("modal-province").textContent = data.province;
//   document.getElementById("modal-contactNumber").textContent =
//     data.contactNumber;
//   document.getElementById("modal-emailAddress").textContent = data.emailAddress;
//   document.getElementById("modal-notificationDate").textContent =
//     data.notificationDate;
//   document.getElementById("modal-examDate").textContent = data.examDate;
//   document.getElementById("modal-examVenue").textContent = data.examVenue;
//   document.getElementById("modal-proctor").textContent = data.proctor;
//   document.getElementById("modal-status").textContent = data.status;
//   document.getElementById("modal-score1").textContent = data.score1;
//   document.getElementById("modal-score2").textContent = data.score2;
//   document.getElementById("modal-score3").textContent = data.score3;
//   document.getElementById("modal-totalScore").textContent = data.totalScore;
//   document.getElementById("modal-applicationForm").href = data.applicationForm;
// }

// document.addEventListener("DOMContentLoaded", function () {
//   const tableBody = document.getElementById("applicant-table-body");
//   const applicantModal = new bootstrap.Modal(
//     document.getElementById("applicantModal")
//   );

//   tableBody.addEventListener("click", function (event) {
//     if (event.target.closest("button") || event.target.closest("a")) {
//       return;
//     }
//     const modalElement = document.getElementById("applicantModal");

//     modalElement.addEventListener("hidden.bs.modal", function () {
//       removeModalBackdrop();
//     });

//     const closeButton = modalElement.querySelector(".btn-close");
//     if (closeButton) {
//       closeButton.addEventListener("click", function () {
//         applicantModal.hide();
//       });
//     }

//     function removeModalBackdrop() {
//       document.body.classList.remove("modal-open");
//       document.body.style.overflow = "";
//       document.body.style.paddingRight = "";
//       const backdrop = document.querySelector(".modal-backdrop");
//       if (backdrop) {
//         backdrop.remove();
//       }
//     }

//     const row = event.target.closest(".applicant-row");
//     if (row) {
//       const data = {
//         applicantID: row.querySelector(".applicant-id").textContent.trim(),
//         name: row.querySelector(".applicant-name").textContent.trim(),
//         sex: row.querySelector(".applicant-sex").textContent.trim(),
//         province: row.querySelector(".applicant-province").textContent.trim(),
//         contactNumber: row.querySelector(".contact-number").textContent.trim(),
//         emailAddress: row.querySelector(".email-address a").textContent.trim(),
//         notificationDate: row
//           .querySelector(".applicant-notification-date")
//           .textContent.trim(),
//         examDate: row.querySelector(".applicant-exam-date").textContent.trim(),
//         examVenue: row
//           .querySelector(".applicant-exam-venue")
//           .textContent.trim(),
//         proctor: row.querySelector(".proctor").textContent.trim(),
//         status: row.querySelector(".status").textContent.trim(),
//         score1: row.querySelector(".applicant-score1")
//           ? row.querySelector(".applicant-score1").textContent.trim()
//           : "N/A",
//         score2: row.querySelector(".applicant-score2")
//           ? row.querySelector(".applicant-score2").textContent.trim()
//           : "N/A",
//         score3: row.querySelector(".applicant-score3")
//           ? row.querySelector(".applicant-score3").textContent.trim()
//           : "N/A",
//         totalScore: row.querySelector(".total-score")
//           ? row.querySelector(".total-score").textContent.trim()
//           : "N/A",
//         applicationForm: row.querySelector(".attachment a").href,
//       };

//       populateModal(data);
//       applicantModal.show();
//     }
//   });
// });
